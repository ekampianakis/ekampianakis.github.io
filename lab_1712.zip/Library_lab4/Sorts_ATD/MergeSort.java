package Sorts_ATD;

import tuc.ece.cs111.fourthassignment.Book;
import tuc.ece.cs111.fourthassignment.BookReader;

public class MergeSort {

	private Book[] list;

	public MergeSort(Book[] listToSort) {
		list = listToSort;
	}

	public Book[] getList() {
		return list;
	}
	public void sort() {
		list = sort(list);
	}
	private Book[] sort(Book[] whole) {
		if (whole.length == 1) {
			return whole;
		} else {
			// Create an array to hold the left half of the whole array
			// and copy the left half of whole into the new array.
			Book[] left = new Book[whole.length / 2];
			System.arraycopy(whole, 0, left, 0, left.length);

			// Create an array to hold the right half of the whole array
			// and copy the right half of whole into the new array.
			Book[] right = new Book[whole.length - left.length];
			System.arraycopy(whole, left.length, right, 0, right.length);

			// Sort the left and right halves of the array.
			left = sort(left);
			right = sort(right);

			// Merge the results back together.
			merge(left, right, whole);

			return whole;
		}
	}

	private void merge(Book[] left, Book[] right, Book[] whole) {
		int leftIndex = 0;
		int rightIndex = 0;
		int wholeIndex = 0;

		// As long as neither the left nor the right array has
		// been used up, keep taking the smaller of left[leftIndex]
		// or right[rightIndex] and adding it at both[bothIndex].
		while (leftIndex < left.length && rightIndex < right.length) {
			if (left[leftIndex].getTitle().compareTo(right[rightIndex].getTitle()) < 0) {
				whole[wholeIndex] = left[leftIndex];
				leftIndex++;
			} else {
				whole[wholeIndex] = right[rightIndex];
				rightIndex++;
			}
			wholeIndex++;
		}

		Book[] rest;
		int restIndex;
		if (leftIndex >= left.length) {
			// The left array has been use up...
			rest = right;
			restIndex = rightIndex;
		} else {
			// The right array has been used up...
			rest = left;
			restIndex = leftIndex;
		}

		// Copy the rest of whichever array (left or right) was
		// not used up.
		for (int i = restIndex; i < rest.length; i++) {
			whole[wholeIndex] = rest[i];
			wholeIndex++;
		}
	}

	public static void main(String[] args) {

		BookReader reader = new BookReader();
		Book book[] = reader.readBooks();
		Book titles[] = reader.readBooks();
		MergeSort q = new MergeSort(titles);
		q.sort();

		for (int i = 0; i < 1000; i++) {
			titles[i].printBook();
		}

	}
}
