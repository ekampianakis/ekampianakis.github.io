package Sorts_ATD;




import tuc.ece.cs111.fourthassignment.Book;


public class LinkedList{
	private LNode root;
	private int size;
	private LNode current;
	
	
	public LinkedList(){
		this.root = null;
		this.current = root;
		size = 0;
	}
	
	public void add(Book book){
		if(root == null){
			root = new LNode(book);
			this.current = root;
		}else{
			current.next = new LNode(book);
			current = current.next;
		}
		size++;
	
		
	}
	
	public int size(){
		return this.size;
	}
	
	public Book get(int index){
		LNode node = root;
		if(root != null){
			
			for(int i  = 0 ; i < index ; i++ ){
				if(node.next != null){
					node = node.next;
				}else{
					node = null;
					break;
				}
			}
		}
		return node.book;
			
		
	}
	
	public void remove(int index){
		LNode node = root;
		if(index == 0){
			root = root.next;
		}
		if(root != null){
			for(int i  = 0 ; i < index-1 ; i++ ){
				if(node.next != null ){
					node = node.next;
				}else{
					node = null;
					break;
				}
			}
			node.next = node.next.next;
		}
		size--;
			
		
	}
	
	public boolean isEmpty(){
		return root == null;
	}
	
	public static void main(String args[]){
		LinkedList list = new LinkedList();
		
		for(int i = 0 ; i < 10 ; i++){
			Book book = new Book();
			book.setAuthor("l" + i);
			list.add(book);
		}
		for(int i = 0 ; i < 10 ; i ++ ){
			System.out.println(list.get(i).getAuthor());
		}
		
		
		
	}
	
}
