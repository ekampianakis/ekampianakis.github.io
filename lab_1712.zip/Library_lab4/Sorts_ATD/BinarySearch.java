package Sorts_ATD;

import tuc.ece.cs111.fourthassignment.Book;
import tuc.ece.cs111.fourthassignment.BookReader;

public class BinarySearch {

	public BinarySearch(){
		
	}
	
	public LinkedList searchByPrice(Float price , Book[] books){
		LinkedList list = new LinkedList();
		int r = books.length;
		int l = 0;
		int index = -1;
		int err = 0;
		
		while(r >= 1){
			err++;
			if(err == books.length){
				break;
			}
			int m = (l+r)/2;
			if(price == books[m].getPrice()){
				index = m;
				break;
			}
			if(price < books[m].getPrice()){
				r = m-1;
			}else{
				l = m+1;
			}
		}
		if(index == -1){
			
			return list;
		}else{
			for(int i = index ; i < books.length ; i++){
				if(books[i].getPrice() == price){
					list.add(books[i]);
				}else{
					break;
				}
			}
			for(int i = index ; i < 0 ; i--){
				if(books[i].getPrice() == price){
					list.add(books[i]);
				}else{
					break;
				}
			}
			return list;
		}
		
	}
	public LinkedList searchByAuthor(String author , Book[] books){
		LinkedList list = new LinkedList();
		int r = books.length-1;
		int l = 0;
		int index = -1;
		int err = 0;
		
		while(r >= 1){
			err++;
			if(err == books.length){
				break;
			}
			int m = (l+r)/2;
			if(author.equalsIgnoreCase(books[m].getAuthor())){
				index = m;
				break;
			}
			if(author.compareToIgnoreCase(books[m].getAuthor()) < 0){
				r = m-1;
			}else{
				l = m+1;
			}
		}
		if(index == -1){
			
			return list;
		}else{
			for(int i = index ; i < books.length ; i++){
				if(books[i].getAuthor().equalsIgnoreCase(author)){
					list.add(books[i]);
				}else{
					break;
				}
			}
			for(int i = index ; i < 0 ; i--){
				if(books[i].getAuthor().equalsIgnoreCase(author)){
					list.add(books[i]);
				}else{
					break;
				}
			}
			return list;
		}
	}
	
	public LinkedList searchByTitle(String title , Book[] books){

		LinkedList list = new LinkedList();
		int r = books.length-1;
		int l = 0;
		int index = -1;
		int err = 0;
		
		while(r >= 1){
			err++;
			if(err == books.length){
				break;
			}
			int m = (l+r)/2;
			if(title.equalsIgnoreCase(books[m].getTitle())){
				index = m;
				break;
			}
			if(title.compareToIgnoreCase(books[m].getTitle()) < 0){
				r = m-1;
			}else{
				l = m+1;
			}
		}
		if(index == -1){
			
			return list;
		}else{
			for(int i = index ; i < books.length ; i++){
				if(books[i].getTitle().equalsIgnoreCase(title)){
					list.add(books[i]);
				}else{
					break;
				}
			}
			for(int i = index ; i < 0 ; i--){
				if(books[i].getTitle().equalsIgnoreCase(title)){
					list.add(books[i]);
				}else{
					break;
				}
			}
			return list;
		}
	
	}
	
	public static void main(String args[]){
		BinarySearch s = new BinarySearch();
		BookReader reader = new BookReader();
		Book authors[] = reader.readBooks();
		QuickSortByAuthor sba = new QuickSortByAuthor();
		sba.quicksortByAuthor(authors);
		LinkedList l = new LinkedList();
		
		l = s.searchByAuthor("goldstein", authors);
		
		for(int i = 0 ; i < l.size() ; i++){
			l.get(i).printBook();
		}
	}
	
}
