package Sorts_ATD;
import tuc.ece.cs111.fourthassignment.Book;
import tuc.ece.cs111.fourthassignment.BookReader;

public class QuickSortByAuthor {


	public void quicksortByAuthor(Book[] books) {
		quicksort(books, 0, books.length - 1);
	}
	

	private void quicksort(Book[] books, int left, int right) {
		if (right <= left)
			return;
		int i = partition(books, left, right);
		quicksort(books, left, i - 1);
		quicksort(books, i + 1, right);
	}

	private int partition(Book[] books, int left, int right) {
		int i = left - 1;
		int j = right;
		while (true) {
			for(;books[++i].getAuthor().compareTo(books[right].getAuthor()) <0;)
								// find item on left to swap
				; 				// a[right] acts as sentinel
			for (;books[right].getAuthor().compareTo(books[--j].getAuthor())<0;)
								// find item on right to swap
				if (j == left)
					break;		// don't go out-of-bounds
			if (i >= j)
				break; 			// check if pointers cross
			exch(books, i, j);  // swap two elements into place
		}
		exch(books, i, right);  // swap with partition element
		return i;
	}

	private void exch(Book[] books, int i, int j) {
		Book temp = books[i];
		books[i] = books[j];
		books[j] = temp;
	}
	public static void main(String[] args) {
		
		BookReader reader = new BookReader();
		Book book[] = reader.readBooks();
		Book authors[] = reader.readBooks();
		QuickSortByAuthor q = new QuickSortByAuthor();
		q.quicksortByAuthor(authors);
		
		for(int i = 0 ; i < 20 ; i++){
			authors[i].printBook();
		}
	}
}