package Sorts_ATD;

import tuc.ece.cs111.fourthassignment.Book;




public class LNode {
	Book book;
	LNode next;
	
	public LNode(Book book){
		this.book = book;
		next = null;
	}
	
	
	
}