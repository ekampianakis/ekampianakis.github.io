package Sorts_ATD;

import tuc.ece.cs111.fourthassignment.Book;
import tuc.ece.cs111.fourthassignment.BookReader;

public class QuickSortByPrice {


	public void quicksortByPrice(Book[] books) {
		quicksort(books, 0, books.length - 1);
	}
	

	private void quicksort(Book[] books, int left, int right) {
		if (right <= left)
			return;
		int i = partition(books, left, right);
		quicksort(books, left, i - 1);
		quicksort(books, i + 1, right);
	}

	private static int partition(Book[] books, int left, int right) {
		int i = left - 1;
		int j = right;
		for (;;) {
			for (;books[++i].getPrice() < books[right].getPrice();)
								// find item on left to swap
				; 				// a[right] acts as sentinel
			for (;books[right].getPrice() <  books[--j].getPrice();)
								// find item on right to swap
				if (j == left)
					break; 		// don't go out-of-bounds
			if (i >= j)
				break; 			// check if pointers cross
			exch(books, i, j);  // swap two elements into place
		}
		exch(books, i, right);  // swap with partition element
		return i;
	}

	private static void exch(Book[] books, int i, int j) {
		Book temp = books[i];
		books[i] = books[j];
		books[j] = temp;
	}


	public static void main(String[] args) {
		
		BookReader reader = new BookReader();
		Book book[] = reader.readBooks();
		Book authors[] = reader.readBooks();
		QuickSortByPrice q = new QuickSortByPrice();
		q.quicksortByPrice(authors);
		
		for(int i = 0 ; i < 20 ; i++){
			authors[i].printBook();
		}
	}
}