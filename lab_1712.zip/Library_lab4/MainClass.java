import tuc.ece.cs111.fourthassignment.Book;
import tuc.ece.cs111.fourthassignment.BookReader;


public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Program Started");

		Tools tools = new Tools();
		tools.calculateTimes();
		tools.menuPrint();
		
		
	}

}
