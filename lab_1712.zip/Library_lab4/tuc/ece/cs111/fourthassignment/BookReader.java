/**
 * @author Giorgos Anestis, TUC/MUSIC
 *  
 *  This package was created for usage in the cs111 course
 *  
 * @version 1.0
 */

package tuc.ece.cs111.fourthassignment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author ganest
 */
public class BookReader {
  
   Book[] booksTable;
   public final static int TABLE_SIZE = 32338;
   public final static String FILE_NAME = "FinalBooks.csv";
   public final static String SEPARATOR = "\t";
   
   /** Creates a new instance of BookReader */
  public BookReader() {
  }
   
   private File createFile() {
      Class cls = BookReader.class;
      String className = cls.getName();
      StringBuffer sb = new StringBuffer();
      int i = className.lastIndexOf('.');
    
      if (i > 0) {
         sb.append(className.substring(0, i));
	   sb.append(".resources.");	   
      }
      
      String s = sb.toString();
      s=s.replace('.', '/');
      s += FILE_NAME;
      
      File file = new File(s);
      return file;
   }
   
   private void readBooksFromFile(int numOfRerords) {
      
      booksTable = new Book[numOfRerords];
      
      File file = createFile();
      
      BufferedReader inputStream = null;
      try {         
         inputStream = new BufferedReader(new FileReader(file.getAbsolutePath()));
         String line, isbn, title, author, pages, price, cover, subject;               
       
         int index, i;
         i  = 0;
         while ((line = inputStream.readLine()) != null) {                  
            index = line.indexOf(SEPARATOR);
            isbn = line.substring( 0, index);            
            isbn = isbn.substring(1, isbn.length()-1);
            line = line.substring(index+1, line.length());

            index = line.indexOf(SEPARATOR);
            author = line.substring( 0, index);            
            author = author.substring(1, author.length()-1);
            line = line.substring(index+1, line.length());
            
            index = line.indexOf(SEPARATOR);
            title = line.substring( 0, index); 
            title = title.substring(1, title.length()-1);
            line = line.substring(index+1, line.length());
            
            index = line.indexOf(SEPARATOR);
            pages = line.substring( 0, index);            
            line = line.substring(index+1, line.length());
            
            index = line.indexOf(SEPARATOR);
            price = line.substring( 0, index);            
            line = line.substring(index+1, line.length());
                        
            index = line.indexOf(SEPARATOR);
            cover = line.substring( 0, index);            
            cover = cover.substring(1, cover.length()-1);
            line = line.substring(index+1, line.length());
            
            subject = line;
            subject = subject.substring(1, subject.length()-1);
            
            booksTable[i++] = new Book(isbn, author, title, Integer.parseInt(pages),
                                       Float.parseFloat(price), cover, subject);
         }      
      } catch (FileNotFoundException ex) {
         ex.printStackTrace();
      } catch (IOException ex) {
         ex.printStackTrace();
      }
      
   }
  
   public Book[] readBooks() {
      readBooksFromFile(TABLE_SIZE);
      return booksTable;
   }
   
   
}
