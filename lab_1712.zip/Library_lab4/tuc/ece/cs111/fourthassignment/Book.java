/**
 * @author Giorgos Anestis, TUC/MUSIC
 *  
 *  This package was created for usage in the cs111 course
 *  
 * @version 1.0
 */

package tuc.ece.cs111.fourthassignment;

/**
 *
 * @author ganest
 */
public class Book {
   
   private String isbn, author, title, cover, subject;
   private int pages;
   private float price;
   
   /** Creates a new instance of Book */
   public Book(String i, String a, String t, int pg, float p, String c, String s ) {
     isbn = i; 
     author = a;
     title = t; 
     pages =pg;
     price = p;
     cover = c;
     subject = s;            
   }
   
   public Book(){
	   
   }
   //getter
   public String getIsbn() {
      return isbn;
   }
   
   public String getAuthor() {
      return author;
   }
   
   public String getTitle() {
      return title;
   }
   
   public int getPages() {
      return pages;
   }
   
   public float getPrice() {
      return price;
   }
   
   public String getCover() {
      return cover;
   }
    
   public String getSubject() {
      return subject;
   }
         
   //setter
   public void setIsbn( String isbn) {
      this.isbn = isbn;
   }
   
   public void setAuthor(String a) {
      author = a;
   }
   
   public void setTitle( String t) {
      title = t;
   }
   
   public void setPages(int p) {
      pages = p;
   }
   
   public void setPrice(float p) {
      price = p;
   }
   
   public void setCover(String c) {
      cover = c;
   }
   
   public void setSubject(String s) {
      subject = s;
   }

   public void printBook() {
    System.out.println( isbn + "\t" + 
                        author + "\t" +
                        title + "\t" +
                        pages + "\t" +
                        price + "\t" +
                        cover + "\t" +
                        subject + "\n");
   }

}
