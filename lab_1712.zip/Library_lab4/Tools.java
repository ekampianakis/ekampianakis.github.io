import Sorts_ATD.BinarySearch;
import Sorts_ATD.LinkedList;
import Sorts_ATD.MergeSort;
import Sorts_ATD.QuickSortByAuthor;
import Sorts_ATD.QuickSortByPrice;
import tuc.ece.cs111.fourthassignment.Book;
import tuc.ece.cs111.fourthassignment.BookReader;
import tuc.ece.cs111.util.StandardInputRead;


public class Tools {
	Book[] prices;
	Book[] authors;
	Book[] titles;
	Book[] books;
	
	StandardInputRead reader;
	public Tools(){
		reader = new StandardInputRead();
	}
	public void menuPrint(){
		int choice;
		System.out.println("************************");
		System.out.println("*LIBRARY APPLICATION*");
		System.out.println("************************");
		
		System.out.println("\n1. Re-Run!");
		System.out.println("\n2. Search book by author");
		System.out.println("\n3. Search book by title");
		System.out.println("\n4. Search book by price");
		System.out.println("\n5. Exit");
		
		do{
			choice  = reader.readPositiveInt("\nSelect One Of The Above : ");
			if(choice < 0 || choice > 5){
				System.err.println("Your Choice Must Be A Number From 1 To 5");
			}

		}while(choice < 0 || choice > 5);
		
		if(choice == 1){
			this.calculateTimes();
			this.menuPrint();
		}
		if(choice == 2){
			this.searchBookByAuthor();
			this.menuPrint();
		}
		if(choice == 3){
			this.searchBookByTitle();
			this.menuPrint();
		}
		if(choice == 4){
			this.searchBookByPrice();
			this.menuPrint();
			
		}
		if(choice == 5){
			System.exit(0);
		}
	}
	
	public void calculateTimes(){
		
		
		
		
		long startTime;
		long endTime;
		BookReader reader = new BookReader();
		///////////read books/////////
		startTime = System.currentTimeMillis();
		Book abooks[] = reader.readBooks();
		endTime = System.currentTimeMillis();
		System.out.println("\nThe Books Record Table Was Read In: " + (endTime-startTime) + " Milliseconds");
		this.books = abooks;
		Book[] titles = reader.readBooks();
		Book[] prices = reader.readBooks();
		Book[] authors = reader.readBooks();
		
		
		///////start counting time//////////
		startTime = System.currentTimeMillis();
		QuickSortByAuthor sba = new QuickSortByAuthor();
		sba.quicksortByAuthor(authors);
		endTime = System.currentTimeMillis();
		
		///////end counting time//////////
		System.out.println("The Author Index Table Was Sorted Using Quicksort In: " + (endTime-startTime) + " Milliseconds");
		
		
		startTime = System.currentTimeMillis();
		QuickSortByPrice sbp = new QuickSortByPrice();
		sbp.quicksortByPrice(prices);
		endTime = System.currentTimeMillis();
		System.out.println("The Prices Index Table Was Sorted Using QuickSort In: " + (endTime-startTime) + " Milliseconds");
		
		startTime = System.currentTimeMillis();
		MergeSort sbt = new MergeSort(titles);
		sbt.sort();
		endTime = System.currentTimeMillis();
		System.out.println("The Titles Index Table Was Sorted Using Mergesort In: " + (endTime-startTime) + " Milliseconds\n");
		
		this.titles = (Book[])titles.clone();
		System.out.println("Size : " + this.titles.length);
		this.prices = prices.clone();
		this.authors = authors.clone();
	}
	
	public void searchBookByPrice(){
		LinkedList list = new LinkedList();
		float price = -1;
		do{
			price = reader.readPositiveFloat("Give Price To Search For : ");
			if(price == -1){
				System.err.println("Please Give A Valid Price!");
			}
		}while(price == -1);
		BinarySearch s = new BinarySearch();
		
		list =	s.searchByPrice(price, this.prices);
		if(list.size()>0){
			for(int i = 0 ; i < list.size() ; i++){
				list.get(i).printBook();
			}
			reader.readString("All books with price " + price +" printed!");
		}else{
			reader.readString("No books with author " + price +" found!");
		}
	}
	
	public void searchBookByAuthor(){
		LinkedList list = new LinkedList();
		String author = "";
		do{
			author = reader.readString("Give Author To Search For : ");
			if(author.equals("")){
				System.err.println("Please Give A Valid Author!");
			}
		}while(author.equals(""));
		BinarySearch s = new BinarySearch();
		
		list =	s.searchByAuthor(author, this.authors);
		
		if(list.size() > 0){
			for(int i = 0 ; i < list.size() ; i++){
				list.get(i).printBook();
			}
			reader.readString("All books with author " + author +" printed!");
		}else{
			reader.readString("No books with author " + author +" found!");
		}
	}
	
	public void searchBookByTitle(){

		LinkedList list = new LinkedList();
		String title = "";
		do{
			title = reader.readString("Give Title To Search For : ");
			if(title.equals("")){
				System.err.println("Please Give A Valid Title!");
			}
		}while(title.equals(""));
		BinarySearch s = new BinarySearch();
		
		list =	s.searchByTitle(title, this.titles);
		
		if(list.size() > 0){
			for(int i = 0 ; i < list.size() ; i++){
				list.get(i).printBook();
			}
			reader.readString("All books with title " + title +" printed!");
		}else{
			reader.readString("No books with title " + title +" found!");
		}
	
	}
	
	
}

